var annotated_dup =
[
    [ "CSCI441", "namespace_c_s_c_i441.html", "namespace_c_s_c_i441" ]
];