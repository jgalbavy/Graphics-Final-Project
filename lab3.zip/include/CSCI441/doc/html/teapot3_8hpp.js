var teapot3_8hpp =
[
    [ "compute_normal", "teapot3_8hpp.html#ac371d179c12cca8a597675dfcbe2b620", null ]
];