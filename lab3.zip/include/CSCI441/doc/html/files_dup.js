var files_dup =
[
    [ "CSCI441", "dir_00b3eae77e1f3012f8d6fd053c504834.html", "dir_00b3eae77e1f3012f8d6fd053c504834" ]
];